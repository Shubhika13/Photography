<?php

session_start();

// Check if user is logged in
if (!isset($_SESSION["username"])) {
  header("Location: login.php");
  exit();
}
// Connect to database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "booking_form";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// SQL query to retrieve data from the bookings table
$sql = "SELECT * FROM bookings";

$result = $conn->query($sql);

// If there are results, display them in a card layout
if ($result->num_rows > 0) {
  echo "<div class='card-container'>";
  
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<div class='card'>";
    echo "<h3>" . $row["name"]. "</h3>";
    echo "<p><strong>Email:</strong> " . $row["email"]. "</p>";
    echo "<p><strong>Phone:</strong> " . $row["phone"]. "</p>";
    echo "<p><strong>Session Type:</strong> " . $row["session_type"]. "</p>";
    echo "<p><strong>Date:</strong> " . $row["date"]. "</p>";
    echo "<p><strong>Message:</strong> " . $row["message"]. "</p>";
    echo "</div>";
  }
  
  echo "</div>";
} else {
  echo "No results";
}

$conn->close();
?>
<a href="logout.php" class="logout-button">Logout</a>

<style>
.card-container {
  display: flex;
  flex-wrap: wrap;
}

.card {
  background-color: #fff;
  box-shadow: 0 2px 2px rgba(0, 0, 0, 0.3);
  padding: 20px;
  margin: 10px;
  width: 300px;
}

.card h3 {
  margin-top: 0;
}

.card p {
  margin-bottom: 10px;
}

.card strong {
  display: inline-block;
  width: 100px;
  font-weight: bold;
}

.logout-button {
  background-color: #4CAF50;
  color: #fff;
  padding: 10px 20px;
  border-radius: 5px;
  border: none;
  cursor: pointer;
}

.logout-button:hover {
  background-color: #3e8e41;
}
</style>