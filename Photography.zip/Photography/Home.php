<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve the form data
  $name = $_POST['name'];
  $email = $_POST['email'];
  $message = $_POST['message'];

  // Connect to the database
  $host = 'localhost';
  $user = 'root';
  $password = '';
  $database = 'contact_form';
  $conn = mysqli_connect($host, $user, $password, $database);

  // Check for errors
  if (!$conn) {
    die('Error connecting to the database.');
  }

  // Insert the form data into the database
  $query = "INSERT INTO messages (name, email, message) VALUES ('$name', '$email', '$message')";
  $result = mysqli_query($conn, $query);

  // Check for errors
  if (!$result) {
    die('Error inserting data into the database.');
  }

  // Close the database connection
  mysqli_close($conn);

  // Redirect the user to a thank-you page
  header('Location: Home.php');
  exit;
}
?>

    <!DOCTYPE html>
    <html>

    <head>
        <title>Client Wedding Photography</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="Home.css">
    </head>

    <body>
        <header>
            <!-- <h1>Client Photography</h1> -->
            <div class="navbar-brand text-center">
                <a href="index.html"><img src="./Screenshot 2023-05-16 104608.png" alt="" data-src="style/images/logo.png" data-ret="style/images/logo@2x.png" class="retina" /></a>
            </div>
        </header>
        <nav>

            <ul>

                <li><a href="Home.php"><b>Home</b></a></li>
                <li><a href="#contact-us"><b>About</b></a></li>
                <li><a href="#featured-gallery"><b>Gallery</b></a></li>
                <li><a href="./service.html"><b>Service</b></a></li>
                <li><a href="./book.php"><b>Booking</b></a></li>
              
                <!-- <li><a href="#location"><b>Location</b></a></li> -->
                <li><a href="#contact"><b>Contact</b></a></li>
            </ul>
        </nav>

        <!-- Slideshow container -->
        <div class="slideshow-container">

            <!-- Full-width images with number and caption text -->
            <div class="mySlides fade">
                <div class="numbertext">1 / 4</div>
                <img src="style/images/pexels-ankur-kumar-3872610.jpg" style="width:100%">
                <div class="text"></div>
            </div>

            <div class="mySlides fade">
                <div class="numbertext">2 / 4</div>
                <img src="style/images/pexels-catalina-carvajal-herrera-14243298.jpg" style="width:100%">
                <div class="text"></div>
            </div>

            <div class="mySlides fade">
                <div class="numbertext">3 / 4</div>
                <img src="style/images/pexels-james-ranieri-2064505.jpg" style="width:100%">
                <div class="text"></div>
            </div>
            <div class="mySlides fade">
                <div class="numbertext">4 / 4</div>
                <img src="style/images/pexels-pixabay-36039.jpg" style="width:100%">
                <div class="text"></div>
            </div>

            <!-- Next and previous buttons -->
            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>
        </div>
        <br>

        <!-- The dots/circles -->
        <div style="text-align:center">
            <span class="dot" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
            <span class="dot" onclick="currentSlide(4)"></span>
        </div>


        <main>
            <section id="welcome">
                <div id="contact-us">
                    <h2>Welcome to our website</h2>

                    <p>At our celebration & event photography portfolio, we understand the significance of capturing and preserving your precious memories. We specialize in documenting life's most special moments, ensuring that each candid moment is beautifully
                        immortalized. Our team of professional photographers is passionate about their craft and dedicated to providing you with a top-notch photographic experience. We believe that every occasion is unique and deserves personalized attention.
                        That's why we offer custom-designed packages tailored to meet your specific needs and preferences. Equipped with state-of-the-art photography equipment and a keen eye for detail, we strive to capture the essence and emotions of
                        your celebrations. Whether it's a wedding, birthday party, anniversary, corporate event, or any other milestone, we have the expertise to cover it all. With our commitment to excellence, we go beyond just taking pictures. We aim
                        to turn your treasured memories into timeless works of art. Each photograph we capture tells a story, evokes emotions, and freezes a moment in time that you can cherish forever. We invite you to explore our Gallery, where you can
                        witness the magic of our photography firsthand. It showcases a selection of our finest work, giving you a glimpse into the range and quality of our portfolio. From candid shots capturing genuine emotions to beautifully composed
                        portraits, our gallery reflects the artistry and skill we bring to every event. If you're ready to discuss your upcoming celebration or event, we encourage you to Contact Us. We offer personalized consultations to understand your
                        vision, discuss your requirements, and tailor our services to meet your expectations. Our team is here to answer any questions you may have and guide you through the process of creating lasting memories.

                    </p>
                    <p>Celebrate life's precious moments with our celebration & event photography portfolio. Let us be a part of your special occasions and provide you with a photographic experience that exceeds your expectations. Get in touch with us today
                        and let's embark on this wonderful journey together.</p>
                </div>

            </section>

            <section id="featured-gallery" class="featured-gallery">
                <div id="contact-us">
                    <h2>Featured Gallery</h2>
                </div>
                <div class="gallery-container">
                    <div class="gallery-item">
                        <img src="./bridal-gb1331672e_640.jpg" alt="Ceremonial photoshoot">
                        <span class="image-overlay">Wedding</span>
                    </div>
                    <div class="gallery-item">
                        <img src="./baby-g5ac4abb18_640.jpg" alt="Baby photoshoot">
                        <span class="image-overlay">Baby</span>
                    </div>
                    <div class="gallery-item">
                        <img src="./woman-g385998052_640.jpg" alt="Fashion photoshoot">
                        <span class="image-overlay">Fashion</span>
                    </div>
                    <div class="gallery-item">
                        <img src="./happy-birthday-g91c752b40_640.jpg" alt="Birthday photoshoot">
                        <span class="image-overlay">Birthday</span>
                    </div>
                    <div class="gallery-item">
                        <img src="./lizard-gf98b135a5_640.jpg" alt="Wildlife photoshoot">
                        <span class="image-overlay">Wildlife</span>
                    </div>
                </div>
            </section>


            <div class="row">
                <section id="contact-us">
                    <h2>IT’S EASY TO FIND US</h2>
                    <p>Feel free to reach out to us for any inquiries, concerns, or support regarding your event photography needs. We are here to assist you every step of the way, ensuring a seamless and memorable experience for your special occasion.
                        <p>Contact us for more information on our packages and customization options.</p>
                    </p>
                </section>

                <section id="location" class="col-md-6">
                    <div class="details">
                        <div class="phone">
                            <img src="./Phone.jpeg" alt="">
                            <h3>PHONE</h3>
                            <p>+91-856412348</p>
                        </div>

                        <div class="mail">
                            <img src="./mail.jpeg" alt="">
                            <h3>EMAIL- </h3>

                            <p>picapture4425@gmail.com
                            </p>
                        </div>
                    </div>

                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60487.07608195702!2d73.85674331084698!3d18.516726195045865!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bedf7b3e4793%3A0x9c79dce2eb8c90ba!2sPune%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1651827568657!5m2!1sen!2sin"
                        width="80%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

                </section>

                <section id="contact" class="contact col-md-6">
                    <h2>Contact Us</h2>
                    <form action="Home.php" method="POST" onsubmit="return validateForm()">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" required><br>
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required><br>
                        <label for="message">Message:</label><br>
                        <textarea id="message" name="message" required></textarea><br>
                        <input type="submit" value="Submit">
                    </form>
                </section>
            </div>

        </main>
        <footer>
            <p>Copyright &copy; Client Photography</p>
        </footer>

        <script src=" ./Home.js ">
        </script>
    </body>

    </html>