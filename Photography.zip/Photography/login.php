<?php
session_start();

// Check if user is already logged in
if (isset($_SESSION["username"])) {
  header("Location: admin.php");
  exit();
}

// Check if the user submitted the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = $_POST["username"];
  $password = $_POST["password"];

  // Check if the username and password are correct
  if ($username == "admin" && $password == "password123") {
    // Save the username in the session
    $_SESSION["username"] = $username;
    header("Location: admin.php");
    exit();
  } else {
    $error = "Invalid username or password";
  }
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Login</title>
  <style>
  body {
    background-color: #f2f2f2;
    font-family: Arial, sans-serif;
  }

  h1 {
    text-align: center;
    color: #4CAF50;
    margin-top: 50px;
  }

  form {
    text-align: center;
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  }

  form label {
    display: block;
    font-weight: bold;
    margin-bottom: 10px;
  }

  form input[type="text"],
  form input[type="password"] {
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    margin-bottom: 20px;
  }

  form input[type="submit"] {
    background-color: #4CAF50;
    color: #fff;

    padding: 10px 20px;
    border-radius: 5px;
    border: none;
    cursor: pointer;
  }

  form input[type="submit"]:hover {
    background-color: #3e8e41;
  }

  form .error {
    color: red;
    font-weight: bold;
    margin-top: 10px;
  }
  </style>
</head>

<body>
  <h1>Login</h1>
  <?php if (isset($error)): ?>
  <p><?php echo $error; ?></p>
  <?php endif; ?>
  <form method="POST">
    <label for="username">Username:</label>
    <input type="text" name="username" required><br>
    <label for="password">Password:</label>
    <input type="password" name="password" required><br>
    <input type="submit" value="Login">
  </form>
</body>

</html>