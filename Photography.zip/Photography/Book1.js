const emailInput = document.getElementById("email");

emailInput.addEventListener("blur", function () {
  const email = emailInput.value;
  const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; // regular expression for email validation
  if (!emailRegex.test(email)) {
    alert("Please enter a valid email address");
    emailInput.focus();
  } else {
    alert("Thank you for entering a valid email address!");
  }
});
