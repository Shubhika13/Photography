// select the form element
const form = document.querySelector('form');

// select the input fields
const emailInput = document.querySelector('#email');
const phoneInput = document.querySelector('#phone');
const sessionTypeInput = document.querySelector('#session-type');
const dateInput = document.querySelector('#date');
const messageInput = document.querySelector('#message');

// function to validate email format
function isValidEmail(email) {
    const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
    return emailRegex.test(email);
}

// function to validate phone format
function isValidPhone(phone) {
    const phoneRegex = /^[0-9]{10}$/;
    return phoneRegex.test(phone);
}

// function to validate the form on submit
function validateForm(event) {
    // prevent form submission
    event.preventDefault();

    // check if email is valid
    if (!isValidEmail(emailInput.value)) {
        alert('Please enter a valid email address');
        return;
    }

    // check if phone is valid
    if (!isValidPhone(phoneInput.value)) {
        alert('Please enter a valid phone number');
        return;
    }

    // check if session type is selected
    if (sessionTypeInput.value === '') {
        alert('Please select a session type');
        return;
    }

    // check if date is selected
    if (dateInput.value === '') {
        alert('Please select a date');
        return;
    }

    // check if message is entered
    if (messageInput.value === '') {
        alert('Please enter a message');
        return;
    }

    // if all validations pass, submit the form
    alert('Form submitted successfully');
    form.submit();
}

// attach the validation function to the form on submit
form.addEventListener('submit', validateForm);