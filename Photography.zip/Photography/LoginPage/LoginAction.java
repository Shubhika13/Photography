package com.example;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	private String name;
	private String mobile;
	private String email;

	public String execute() {
		return SUCCESS;
	}

	public void validate() {
		if (name == null || name.trim().isEmpty()) {
			addFieldError("name", "Name is required");
		} else if (!name.matches("[a-zA-Z]+")) {
			addFieldError("name", "Name should contain only alphabets");
		}

		if (mobile == null || mobile.trim().isEmpty()) {
			addFieldError("mobile", "Mobile number is required");
		} else if (!mobile.matches("\\d{10}")) {
			addFieldError("mobile", "Mobile number should contain 10 digits");
		}

		if (email == null || email.trim().isEmpty()) {
			addFieldError("email", "Email ID is required");
		} else if (!email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
			addFieldError("email", "Invalid email address");
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
