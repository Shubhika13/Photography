<!DOCTYPE html>
<html>

<head>
    <title>Login Page</title>
</head>

<body>
    <h1>Login Page</h1>
    <form action="login.action" method="POST">
        <label>Name:</label>
        <input type="text" name="name"><br><br>

        <label>Mobile Number:</label>
        <input type="text" name="mobile"><br><br>

        <label>Email ID:</label>
        <input type="email" name="email"><br><br>

        <input type="submit" value="Login">
    </form>
</body>

</html>

<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "mydb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Prepare and bind parameters
$stmt = $conn->prepare("INSERT INTO users (name, mobile, email) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $mobile, $email);

// Get form data
$name = $_POST["name"];
$mobile = $_POST["mobile"];
$email = $_POST["email"];

// Insert data into table
if ($stmt->execute()) {
    header("Location: welcome.jsp");
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>