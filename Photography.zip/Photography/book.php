<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve the form data
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $session_type = $_POST['session-type'];
  $date = $_POST['date'];
  $message = $_POST['message'];

  // Connect to the database
  $host = 'localhost';
  $user = 'root';
  $password = '';
  $database = 'booking_form';
  $conn = mysqli_connect($host, $user, $password, $database);

  // Check for errors
  if (!$conn) {
    die('Error connecting to the database.');
  }

  // Insert the form data into the database
  $query = "INSERT INTO bookings (name, email, phone, session_type, date, message) VALUES ('$name', '$email', '$phone', '$session_type', '$date', '$message')";
  $result = mysqli_query($conn, $query);

  // Check for errors
  if (!$result) {
    die('Error inserting data into the database.');
  }

  // Close the database connection
  mysqli_close($conn);

  // Redirect the user to a thank-you page
  header('Location: Home.php');
  exit;
}
?>


<!DOCTYPE html>
<html>

<head>
  <title>Booking Form</title>
  <link rel="stylesheet" href="./Book.css" />
</head>

<body>
  <header>
    <!-- <h1>Client Photography</h1> -->
    <div class="navbar-brand text-center">
      <a href="index.html"><img src="./Screenshot_2023-05-16_104608-removebg-preview.png" alt="" data-src="style/images/logo.png"
          data-ret="style/images/logo@2x.png" class="retina" /></a>
    </div>
  </header>
  <nav>
    <ul>
      <li><a href="Home.php"><b>Home</b></a></li>
      <!-- <li><a href="Home.php"><b>About Us</b></a></li> -->

    </ul>
  </nav>
  <main>
    <section class="booking-form">
     <div id="contact-us"><h2>Book a Session</h2></div> 
      <form action="book.php" method="POST">
        <div class="form-group">
          <label for="name">Name:</label>
          <input type="name" id="name" name="name" required />
        </div>
        <div class="form-group">
          <label for="email">Email:</label>
          <input type="email" id="email" name="email" required />
        </div>

        <div class="form-group">
          <label for="phone">Phone:</label>
          <input type="tel" id="phone" name="phone" required />
        </div>

        <div class="form-group">
          <label for="session-type">Session Type:</label>
          <select id="session-type" name="session-type" required>
            <option value="">--Select--</option>
            <option value="Wedding">Wedding</option>
            <option value="Baby">Baby</option>
            <option value="Fashion">Fashion</option>
            <option value="Birthday">Birthday</option>
            <option value="Wildlife">Wildlife</option>
          </select>
        </div>

        <div class="form-group">
          <label for="date">Date:</label>
          <input type="date" id="date" name="date" required />
        </div>

        <div class="form-group">
          <label for="message">Message:</label>
          <textarea id="message" name="message" required></textarea>
        </div>

        <button type="submit">Book Now</button>
      </form>
    </section>
  </main>

  <footer>
    <p>Copyright &copy; Client Photography</p>
  </footer>
  <script src="book1.js"></script>
</body>

</html>